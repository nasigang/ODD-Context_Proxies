# WACV 2027 Submission #9876 — Truthful Reproducibility Package

**Track**: WACV 2027 Evaluations & Datasets Track (Track C)  
**Title**: Beyond the Nearest Actor: A Scenario-Disjoint Audit of Current-Frame ODD-Context Proxies in the Waymo Open Motion Dataset

---

## 1. Scope and Exact Disclaimer
This package provides authoritative, machine-readable validation data and an automated reproduction script for the locked empirical tables and figure in the paper:
- **Verified Tables**:
  - `Table 1` (Main Manuscript): Primary Nested Model Evaluation ($M_P$, $M_E$, $M_{P+E_{\text{static}}}$, $M_{P+E_{\text{comp}}}$, $M_{P+E_{\text{interact}}}$, $M_{P+E_{\text{all}}}$).
  - `Table 3` (Supp Table 1): 13-Feature Holdout Confirmation Breakdown ($10/13$ confirmed, $13/13$ sign concordant).
  - `Table 4` (Supp Table 4): Supportive Within-Dataset Vehicle-Response KPI Alignment ($ho = +0.1347$, Cohen's $d = +0.3451$).
- **Verified Figures**:
  - `Figure 2` (Main Manuscript): Forest Plot of model contrasts with $95\%$ scenario-block bootstrap confidence intervals (raster forest plot generated from the supplied aggregate values).

### Dataset License and Raw Data Boundary
Under the **Waymo Open Motion Dataset (WOMD) License Agreement**, raw TFRecords and individual per-frame derived records cannot be redistributed in this supplementary package. Researchers wishing to process raw frames or retrain models must obtain authorized access directly from the official Waymo portal: https://waymo.com/open.

---

## 2. Directory Structure
```text
reproducibility/
├── README.md
├── CLAIM_EVIDENCE_LEDGER.csv
├── reproduce_paper_assets.py
└── data/
    ├── TABLE1_NESTED_MODELS_V6.csv
    ├── TABLE2_THRESHOLD_SENSITIVITY_V6.csv
    ├── TABLE3_FEATURE_CONFIRMATION_V6.csv
    ├── TABLE4_REPAIRED_SCENARIO_EFFECTS_V6.csv
    ├── KPI_CONSTRUCT_VALIDITY_V6.csv
    └── TEMPORAL_DOWNSAMPLING_EVIDENCE_V6.csv
```

---

## 3. Reproduction Instructions
To reproduce the aggregate verification checks and generate `reproduced_fig2_forest_plot.png`:

```bash
python reproduce_paper_assets.py
```

### Expected Output:
```text
=================================================================
WACV 2027 Submission #9876 — Truthful Asset Reproduction
=================================================================
  [✓] Table 1 Primary Results: Verified exact match
  [✓] Table 3 Feature Confirmation: Verified 10/13 confirmed & 13/13 sign concordance
  [✓] Table 4 KPI Alignment: Verified rho=+0.1347, d=+0.3451
  [✓] Figure 2 Forest Plot: Successfully reproduced
=================================================================
SUCCESS: Selected aggregate checks passed; Figure 2 reproduced.
=================================================================
```
